from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0005_hero_slide"),
        ("core", "0006_rename_core_metric_mmkt_ts_idx_core_machin_machine_7921d9_idx"),
    ]

    operations = []
